# Import the random module
# compare function
# loop if it's wrong and right.
import art
from game_data import data

import random

# Generate a random account from the game data.


def format_data(card):
    """Format the account data into printable fromat"""
    card_name = card['name']
    card_descr = card['description']
    card_country = card['country']
    return f"{card_name},a {card_descr}, from {card_country}"

# Check if user is correct.
# Get follower count of each account.
# Use if statement to check if user is correct.


def check_answer(guess, a_follower, b_follower):
    """take user guess and bigger follower account and returns if they got it right"""
    if a_follower > b_follower:
        return guess == "a"
    else:
        return guess == "b"


# Display art
print(art.logo)
score = 0
game_should_countinue = True
b_card = random.choice(data)
# Make the game repeatable.
while game_should_countinue:
    # Making account at position B become the next account at position A.
    a_card = b_card
    b_card = random.choice(data)
    if a_card == b_card:
        b_card = random.choice(data)

    print(f"compare A: {format_data(a_card)}")
    print(art.vs)
    print(f"Against B: {format_data(b_card)}")
    # Ask user for a guess.
    guess = input("Who has more followers? Type 'A' or 'B': ").lower()
    a_card_follower = a_card['follower_count']
    b_card_follower = b_card['follower_count']

    is_correct = check_answer(guess, a_card_follower, b_card_follower)
# Clear the screen between rounds.
    cls()
    print(art.logo)
# Score keeping
# Give user feedback on their guess.
    if is_correct:
        score += 1
        print(f"You're right! Current score: {score}.")
    else:
        game_should_countinue = False
        print(f"Sorry, that's wring. Final score: {score}")
